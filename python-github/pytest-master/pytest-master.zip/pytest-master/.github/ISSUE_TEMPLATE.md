Thanks for submitting an issue!

Here's a quick checklist in what to include:

- [ ] Include a detailed description of the bug or suggestion
- [ ] `pip list` of the virtual environment you are using
- [ ] pytest and operating system versions
- [ ] Minimal example if possible
