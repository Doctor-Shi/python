def test_init():
    pass
